	    |-------|		    |-------|		    |-------|
	    |       |		    |       |		    |       |
	    |       |		    |       |		    |       |
	|-------|-------|	|-------|-------|	|-------|-------|
	|       |       |	|       |       |	|       |       |
	|       |       |	|       |       |	|       |       |
    |-------|-------|-------|-------|-------|-------|-------|-------|-------|
    |       |       |       |       |       |       |       |       |       |
    |       |       |       |       |       |       |       |       |       |
|-------| TTTTT |RRRRR  | IIIII | PPP   | EEEEE |   A   | K  K  |  SSS  |-------|
|       |   T   |R    R |   I   | P  P  | E     |  A A  | K K   | S   S |       |
|       |   T   |R    R |   I   | P   P | E     | A   A | KK    |S      |       |
|       |   T   |RRRRR  |   I   | PPPP  | EEEE  | AAAAA | KK    | SSSS  |       |
|       |   T   |R  R   |   I   | P     | E     | A   A | K K   |     S |       |
|-------|   T   |R   R  | IIIII | P     | EEEEE |A     A| K  K  |  SSS  |-------|

TriPeaks Solitaire in Java v3.0

0. INTRODUCTION:
================

Thank you for downloading my game. It is a Java implementation of TriPeaks solitaire.
I felt it was necessary to create this game in Java because many Windows versions exist.
Since Java is platform-independent, you will be able to use it on any computer with Java.
Extracting it to a flash drive lets you take your scores with you wherever you go.
***NOTE*** Unless there is a must-have feature in this version, I would recommend using
v2.1, as it has less bugs and is more stable.
Now, onto the gameplay.

1. GAMEPLAY:
============

NOTE: It may be helpful to start the game right about now, so it's easier to follow along.

Once you deal, you'll get a randomized board - 28 cards "in play", 23 cards in the deck,
and 1 card in the discard pile. "In play" refers to any card that's not in the deck or the
discard pile. The cards in the deck are face-down, along with all but the bottom row of the
cards in play. The bottom row of cards and the discard pile are all face-up. 

To move cards to the discard pile, they need to be "adjacent" in value to the current
card in the discard pile. So, if you have an Ace in the discard pile, you can remove a King
or a Two. Note that the Ace and King are considered to be adjacent. Also, the suit doesn't
matter in this game. It's just there to have 52 cards altogether.

If there is no card that can be removed, a card can be taken from the deck and put into the
discard pile. When a card has no cards covering it, it's flipped.

2. SCORING:
===========

Money is the scoring system for the game. Don't get excited; it's not real. I'm not going
to write you checks for however much you win in this game. I will use the words dollars,
points, and money interchangeably in this section.

When you remove a card, you get some money. The more cards you remove, the more money you
get. In the game, there are "streaks", or the number of cards you remove in a row without
taking a card from the deck. For every card you remove, you get that streak amount. An
example: you get $1 for the first card you remove, $2 for the second, $3 for the third,
and so on.

Your streak ends when you take a card from the deck. First, you'll start over with $1 for
the next card you remove. Second, you'll be penalized $5 for taking the card from the deck.
You can redeal before you remove all the cards or run out of cards in the deck. However,
that results in a penalty of $5 for every card you haven't removed. Again, if you run out
of cards in the deck, there is no penalty for redealing.

3. STRATEGIES:
==============

Obviously try to go for the longest streak. Try to work the streak out in your head,
especially if you have a couple of options. However, this section will focus on when you
have a "choice" between two cards. A choice is when two (or more) cards will give you
the same streak.

When you have a choice, always go with the card(s) that will open up more cards. This
gives you more opportunity to make the streak longer. Even if it doesn't, it'll still
give you more cards to make a streak with. So, if you have a choice between a card that
opens up another card and a peak, don't go with the peak. Unless you only have a few
cards in your deck and don't have a big chance of clearing the board.

Also, if you have a lot of cards in your deck and just one peak to go, you may want to
consider redealing right away. This only costs you $5, but you can lose a lot more if
you keep taking cards from the deck and never clear the board. In addition, getting that
peak will get you $30, so taking more than 6 cards from the deck is nonsense. You'll get
negative profit by clearing the board.

I may add more strategies later. Or, if you have a great tip for the game, email me:
vetruvet@gmail.com

4. CHEATING:
============

I HIGHLY DISCOURAGE CHEATING!!!

However, you can cheat if you are new to the game or are just plain frustrated (or
whatever your reasons are). There are penalties for cheating in this game. First off,
if you haven't cheated yet in this game, then you will be warned when you enter the cheat
menu. Once you enable a cheat, your username WILL BE SCARRED until you reset.

By scarring, I am referring to "CHEATER" being displayed in the background in 132-point
font. Also, "Cheat Mode" is written in the title bar. Your cheater checkbox in the
new highscore table will also be checked. The ONLY way to get rid of that is
to reset your stats. Even if you aren't using any cheats at the moment, the scars will
still be there. Here is your selection of cheats:
 - All cards face up => all cards appear to be face-up. However, if a card would be
                        face-down without the cheat, it still acts like a face-down card.
 - Click any card => you can click any face-up card, regardless of its value. Be warned
                     when using this cheat with the first one - the cards only appear to
                     be face-up; they act like they're face-down.
 - No Penalty => you never get any penalty. There is no penalty for premature dealing,
                 quitting, or whatever. Neither is there a penalty for taking cards from
                 the deck. So essentially, your score never goes down.

A new security feature has benn added to the game. If you modify your (or someone else's)
score file, the modified score file will be deleted. This is so people can't cover up their
cheating by copying and pasting certain lines.

5. MENUS:
=========

Game: Game-playing related stuff
 |---Deal: Redeals (F2 does the same thing). If there's a penalty, you will have to confirm
 |         your intention to redeal.
 |---Switch Player: Switches the current player (asks for another player name). If there's
 |                  a penalty, you'll have to confirm.
 |---Session Graph: Shows a graph of your current session score and averages.
 |---High Scores: Shows a high score table. It is fully sortable by every column. CGP's 
 |                (Computer-Generated-Players) are added if there are less than 10 players.
 |                You can't use the CGP's stats (if you put their name in at the beginning).
 |---Reset: PERMANENTLY resets all your scores and stats. Useful if you're in REALLY big
 |          losses. It will not look at the penalty, but will always ask you to confirm.
 |---Exit: Exits the game. (No, duh.)

Options: Game options
 |---Card Style: Change the Card Style - both front and back.
 |---Board Background: Change the background color of the board.
 |---Text Font: Select the font (and its color) to be used on the board.
 |---Show Stats: Shows/hides your stats at the below the panel with the cards.
 |---Reset Defaults: Reset the default options (card styles, background, and font).

Cheats: Cheat menu (HIGHLY DISCOURAGED)
 |---Cards face up: all cards appear to be face up, but you still can't click the ones
 |                  that would be face-down.
 |---Click any card: allows you to click any face-up card.
 |---No Penalty: no penalty for anything (redeal, take from the deck), so the score
                 never goes down.

Help: Game help and credits
 |---Help: Shows a condensed version of sections 1, 2, 3, and 4 of this file.
 |---About: Displays some short credits.

6. CUSTOMIZING:
===============

You can customize the fronts and backs of cards. I've provided 10 back styles and 2 front
styles to be distributed with the program. You can (and are encouraged) to create your own
card styles. Here's what you need to know:
1. All images will be resized to 64 x 86 pixels when they are painted on the screen (at
   least for now). If the picture is bigger, it will be scaled down. Sometimes, that is
   bad for the look of the image. If at all possible, try to make your custom images 64 x 86.
2. Creating back images. You can now change the background color, so your image can have any
   colors (tell users which background to use). When you're done, save the image as a PNG. If you
   don't, the game won't recognize it. Put the finished image into the CardSets/Backs.
   folder inside the folder where you extracted the game. The game will find it the next
   time you open the 'Card Styles' dialog (you don't have to restart the game).
3. Creating front images. Pretty much the same thing as above. However, now you will have
   52 PNGs: 13 for each suit. Create a new folder in CardSets/Fronts/ with a name of your
   set. You will put your front images in there. They must follow this naming convention:
   suitX.png - suit is the suit of the card (in lowercase, plural: hearts, spades, diamonds,
   clubs), X is the value of the card (use 11, 12, and 13 for Jack, Queen, and King, don't use
   0's in front: 1 instead of 01). Again, the program will recognize the set once you open
   the 'Card Styles' dialog.

As of v2.0b4, you can also pick your own font for the program to use on the board.
However, fonts aren't consistent on all systems! Just because you have a font installed on
your machine, doesn't mean it'll be on another (like when you take it on your flash drive).
In such cases, an alternative font will be chosen by the JRE (not my code). When your
settings get saved, that alternative font will be saved, not your original. You have been
warned, so don't complain when your settings get messed up.

7. FAQ:
=======

1. Why is the game so hard? None of the cards form good streaks?
   The game is RANDOMIZED. There are no "difficulty levels". Just keep playing. My highest
   streak (so far) is 19 cards in a row.
2. Why didn't you use JAR? Isn't that the better archive option for Java?
   I would've liked to use JAR to archive the program. However, there is a slight problem
   with that. Java programs running from a JAR can't write/change files in the the JAR. They
   can read, but can't change anything. So, essentially your scores would not change after the
   program exits. (i.e. Read-only high-score table)
3. You know, this game could really use [insert your idea here].
   Ideas are welcome and encouraged. Just send me an email with your ideas: vetruvet@gmail.com
4. How big/long is the code (I'm too lazy to check CVS)?
   At the time of writing this file, the code was 2014 lines long, and was 96.3 KB.
5. Why did you have to "scar" the player if they cheat?
   I highly discourage cheating. It takes a lot of the fun out of the game. However, if you
   are a dedicated cheater, you can still cheat, but the "scarring" is your penalty.
   Cheating is also useful for training or learning the game. New players may not want to
   be discouraged by their losses. However, if they want to send screenshots of high scores
   (or whatever), they can't cheat.
6. If the player modifies their score file, why is the punishment so severe?
   Say, for example, that you use a cheat to get excellend stats for your player. However, the
   player is scarred, right? Well, if that player takes the ecrypted values for 'false' and
   replaces them with the encrypted values for 'true'. Essentially, that player has gotten away
   with cheating (in 2 forms). Deleting the ill-gotten stats is pretty much the only thing to
   do. It also discourages them from doing it again.
7. My question isn't here. Can I get it put here? Or at least answered?
   By all means. If you have a question, I'll answer it (if possible). If you have a GOOD
   question, I'll consider it for this FAQ section, as well as the to-be website one.
   Just send me an email: vetruvet@gmail.com

8. BRIEF HISTORY:
=================

3.0   (09/02/2008) - Final v3.0 release. Fixes a lot of graph bugs.
3.0b5 (08/19/2008) - Fifth beta of 3.0 - Average session graph, applet version completed.
3.0b4 (07/21/2008) - Fourth beta of 3.0 - Added session graph feature (reason for no beta3).
3.0b2 (06/06/2008) - Second beta of 3.0 - More security with scores, added high score features.
3.0b1 (05/30/2008) - First beta with a highscore table...
2.1   (05/25/2008) - A minor corrective re-release (disallowed font dialog resizing).
2.0   (05/21/2008) - Final v2.0 release. Fixes most bugs
2.0b4 (05/12/2008) - Fourth beta of v2.0 - created the Font Selector
2.0b3 (05/05/2008) - Third beta of v2.0 (something happened to the second one...)
2.0b1 (04/21/2008) - First beta of v2.0 - still needs a lot of work
1.0   (04/15/2008) - Final Release of v1.0 of TriPeaks Solitaire in Java.
1.0b4 (04/12/2008) - Second SF.net release. Last one before final.
1.0b3 (04/10/2008) - Initial SF.net release.
1.0b2 (04/07/2008) - Public (non-SF.net) release.
1.0b1 (04/05/2008) - Semi-public (non-SF.net) release